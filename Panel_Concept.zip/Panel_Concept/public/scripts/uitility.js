$(document).ready(function(){

/*$('.list-group-item').addClass('collap');*/
//left menu
$(function() {

    $('#side-menu').metisMenu();

});




/*function toggleChevron(e) {
$(e.target)
.prev('.collap')
.find("i.fa")
.toggleClass('fa-chevron-right fa-chevron-down');

}
$('#MainMenu').on('hidden.bs.collapse', toggleChevron);
$('#MainMenu').on('shown.bs.collapse', toggleChevron);*/




$('.side-bar-collapse').click(function(){
    $('.sidebar-nav').toggle();
    $('#page-wrapper').toggleClass('custom1');
	 $(this).find('.fa').toggleClass('fa-chevron-left fa-chevron-right');
    });
$(document).on('click', '.panel-heading button.clickable', function(e){
    var $this = $(this);
	if(!$this.hasClass('panel-collapsed')) {
		$this.parents('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.find('i').removeClass('fa-chevron-up').addClass('fa-chevron-down');
	} else {
		$this.parents('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.find('i').removeClass('fa-chevron-down').addClass('fa-chevron-up');
	}
})

var sidebar_height = $('.sidebar').height();
var pagebar_height = $('#page-wrapper').height();
 
// if(pagebar_height < sidebar_height)
// {
// $('#page-wrapper').height(sidebar_height);
// }
// if(pagebar_height > sidebar_height)
// {
// $('.nano-menu').css("height",pagebar_height);
// $(".nano").nanoScroller();
// }
$(".nano").nanoScroller(); 

$('.list-group-item').click(function()
{ 
/*var sidebar_height = $('.sidebar').height();
var pagebar_height = $('#page-wrapper').height();
console.log(sidebar_height+" >>> "+pagebar_height);
if(pagebar_height < sidebar_height)
{
$('#page-wrapper').height(sidebar_height);
}
if(pagebar_height > sidebar_height)
{
$('.nano-menu').css("height",pagebar_height);*/
$(".nano").nanoScroller();
//}
});
}); 


$(document).ready(function()
{
$('#menu').on('shown.bs.collapse', function (e) {
	var target_nano = $(e.target).prev('a'); 
	$("#nano_menu").nanoScroller({ scrollTo: $(target_nano) })
});

// Menu_submenu(17/4/2017)//


$(".list-group-item").click(function()
 {
var taget_id = $(this).attr("data-target");
	if($(taget_id).attr("level")=="child")
	{
	$("div[level='sub_child']" ).removeClass("in");
	 $("div[level='sub_child']" ).attr("aria-expanded","false");	
		if($(this).find('.fa').hasClass("fa-chevron-right"))
		{		
				$(".list-group-item").find(".pull-right").each(function()
				{
					if($(this).hasClass("fa-chevron-down"))
					{
					$(this).addClass('fa-chevron-right').removeClass('fa-chevron-down');
					}else
					{
					}
				})
			$(this).find('.fa').removeClass('fa-chevron-right').addClass('fa-chevron-down');
		}else
		{
			$(this).find('.fa').addClass('fa-chevron-right').removeClass('fa-chevron-down');	
		}	
}else if($(taget_id).attr("level")=="sub_child")
{
if($(taget_id).css("display") == "none")
{

$(taget_id).attr("aria-expanded","true");
}else
{

$(taget_id).attr("aria-expanded","false");
}

	if($(this).find('.fa').hasClass("fa-chevron-right"))
	{	
	
		$(".sub_child").each(function()
		{
			if($(this).css("display")=="block")
			{
			$(this).removeClass("in");
			var targetchild_id = $(this).attr("id")
			$("."+targetchild_id).find('.fa').addClass('fa-chevron-right').removeClass('fa-chevron-down');
			}
		});
		
	$(this).find('.pull-right').removeClass('fa-chevron-right').addClass('fa-chevron-down');	
	}else
	{
	$(this).find('.pull-right').addClass('fa-chevron-right').removeClass('fa-chevron-down');
	}
	}


});
});

