/*function validatePost (to,p) {
  var myForm = document.createElement("form");
	  myForm.method="post" ;
	  myForm.action = to ;
  for (var k in p) {
    var myInput = document.createElement("input") ;
    myInput.setAttribute("name", k) ;
    myInput.setAttribute("value", p[k]);
    myForm.appendChild(myInput) ;
  }
  document.body.appendChild(myForm) ;
  myForm.submit() ;
  document.body.removeChild(myForm) ;
}*/

function validatePost (to,id,imgurl) 
{
	var tanchors = document.getElementById('MainMenu').getElementsByTagName('a').length;
	for(var j=0;j<tanchors;j++)
	{
		menuid = "menua"+j;
		if(menuid == id)
		{
			document.getElementById(menuid).className = "";
			document.getElementById(menuid).className = "list-group-item active";
			document.getElementById('menuimg').src = imgurl;
		}
		else
		{
			document.getElementById(menuid).className = "";
			document.getElementById(menuid).className = "list-group-item";
		}
	}
}

function accountclick()
{
	alert("Settings is in inprogress");
}