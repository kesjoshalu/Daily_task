function checkCredentials()
{
	var uname = document.getElementById('txt_username').value;
	var password = document.getElementById('txt_password').value;
	if(uname == '' && password == '')
	{
		document.getElementById('errorspan').innerHTML = "Kindly enter the username and password"; 
		document.getElementById('error_div').style.display = "block";
		return false;
	}
	else if(uname == '')
	{
		document.getElementById('errorspan').innerHTML = "Kindly enter the username"; 
		document.getElementById('error_div').style.display = "block";
		return false;
	}
	else if(password == '')
	{
		document.getElementById('errorspan').innerHTML = "Kindly enter the password"; 
		document.getElementById('error_div').style.display = "block";
		return false;
	}
	else
	{
		document.form_submit.action = "index.php?rt=login/initUser";
		document.form_submit.submit();
	}
}

function checkUserImage()
{
	var uname = document.getElementById('txt_username').value;
	if(uname != '')
	{
		$.ajax({		
			type: "POST",
			cache: false,
			data: { uname: uname}, 
			url: "index.php?rt=login/getPhotoPath",
			success: function(response)
			{
				document.getElementById('userphoto').src = response;
			}
		});	
	}
}