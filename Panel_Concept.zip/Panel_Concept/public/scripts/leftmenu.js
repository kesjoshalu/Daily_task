$(document).ready(function()
{
/* for menu retaining operation starts */
    setTimeout(function(){
		var urlarray  = new Array();
      $("body").find("#menu").children().find(".current_click").each(function(){
		 
		urlarray.push($(this).data("url"));
		// alert($(this).data("url"))
        if(active_url == $(this).data("url"))
        {		
			parent_id = $(this).data("id");
			// $("#pid_"+parent_id).trigger('click');
			if($(this).data('class') == 'main')
			{
				$("#pid_"+parent_id).trigger('click');
				// $('#'+$(this).parent().parent().data('extendid')).css('display','block');
			}
			if($(this).data('class') == 'parent')
			{
				// nothing
			}
			else
			{
				// alert($(this).parent().parent().data('extendid'))
				$("#"+$(this).parent().parent().data('extendid')).trigger('click');
				$('#'+$(this).parent().parent().data('extendid')).css('display','block');
				$(this).parent().addClass("in");
			}
			$(this).addClass("active");
			var window_height = $(window).height();
			var navbar_header = $(".navbar-header").outerHeight();
			var footer_height = $(".footer1").outerHeight();
			var actually_height = window_height-navbar_header-footer_height;          
			var menu_height =parseInt($(this).offset().top);
			if($(this).parent().hasClass("sublinks"))
			{
				$("#nano_menu").nanoScroller({ scrollTo: $(this).parent().prev('a') });
			}
			else
			{
				if(actually_height > menu_height+200)
				{
              
				}
				else
				{
					$("#nano_menu").nanoScroller({ scrollTo: $(this) });
				}
           
			}
        }
      });
	 // alert(urlarray)
    }, 150);
/* for menu retaining operation end */
});