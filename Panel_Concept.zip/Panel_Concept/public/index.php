<?php
    require_once '../app/dispatcher.php';

    // Init Core Library
    $init = new Core;
