<?php
    class Users extends Controller{
		//define('USERID',$_SESSION['id']);
        public function __construct(){
            $this->userModel = $this->model('User');
            $this->db = new Database;
        }

        // Index page
        public function users() {
			//$value = "fixed";
            $link   = URLROOT.$_SERVER['REQUEST_URI'];
            $pieces = explode("/", $link);
            $last   = array_pop($pieces);

            $pagination = $this->userModel->pagination();
			//$lastInsertedData = $this->userModel->getLastInsertedData();
            $adduser = $this->addNewUser();


            $data = [
                'link'          => $last,
                'pagination'    => $pagination,
				//'lastInsertedData' => $lastInsertedData,
                'adduser'       => $adduser
            ];
            $this->view('users/users', $data);
        }
		

        public function show($id){
            $user = $this->userModel->getUserById($id);

            $data = [
                'user' => $user
            ];
            $this->view('users/show', $data);
			
        }

        public function register(){
            // Chech for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                // Process form

                // Sanitize POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
		/*	if(isset($_POST['name']))
					{
        // Access the value of 'name' field
        $name = $_POST['name'];

        // Now you can use $name as needed, for example:
        echo "The name submitted is: " . $name;
    } else {
        echo "Name field is not set in the form submission.";
    }*/

                $data = [
                    'name'                  => trim($_POST['name']),
                    'email'                 => trim($_POST['email']),
                    'password'              => trim($_POST['password']),
                    'confirm_password'      => trim($_POST['confirm_password']),
                    'country'               => trim($_POST['country']),
                    'name_err'              => '',
                    'email_err'             => '',
                    'password_err'          => '',
                    'confirm_password_err'  => '',
                    'country_err' => ''
                ];
				//echo $_POST['name'];
                // Validite Name
				echo $data['name'];
                if(empty($data['name'])){
                    $data['name_err'] = 'Please Enter Name';
                }

                // Validite Email
                if(empty($data['email'])){
                    $data['email_err'] = 'Please Enter Email';
                } else {
                    // Check Email
                    if($this->userModel->findUserByEmail($data['email'])){
                        $data['email_err'] = 'Email is already taken';
                    }
                }

                // Validite Password
                if(empty($data['password'])){
                    $data['password_err'] = 'Please Enter Password';
                } elseif(strlen($data['password']) < 6){
                    $data['password_err'] = 'Password must be at least 6 characters';
                }

                // Validite Confirm Password
                if(empty($data['confirm_password'])){
                    $data['confirm_password_err'] = 'Please Confirm Password';
                } else {
                    if($data['password'] != $data['confirm_password']){
                        $data['confirm_password_err'] = 'Passwords do not match';
                    }
                }

                // Validate Country
                if(empty($data['country'])){
                    $data['country_err'] = 'Please Enter Country';
                }

                // Make sure errors are empty
                if(empty($data['email_err']) && empty($data['name_err']) && empty($data['password_err']) && empty($data['confirm_password_err']) && empty($data['country_err'])){
                    // Validated

                    // Hash Password
                    $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
						$data['password'] = $data['password'];
                    // Register User
                    if($this->userModel->register($data)){
                        flash('register_success', 'You are registered and can log in');
                        redirect('users/login');
                    } else {
                        die('Something went wrong');
                    }

                } else {
                    // Load view with errors
                    $this->view('users/register', $data);
                }


            } else {
                // Init data
                $data = [
                    'name'                  => '',
                    'email'                 => '',
                    'password'              => '',
                    'confirm_password'      => '',
                    'country'               => '',
                    'name_err'              => '',
                    'email_err'             => '',
                    'password_err'          => '',
                    'confirm_password_err'  => '',
                    'country_err'           => ''
                ];

                // Load view
                $this->view('users/register', $data);
            }
        }

        public function login(){
            // Chech for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                // Process form

                // Sanitize POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                $data = [
                    'email'         => trim($_POST['email']),
                    'password'      => trim($_POST['password']),
                    'email_err'     => '',
                    'password_err'  => ''
                ];

                // Validite Email
                if(empty($data['email'])){
                    $data['email_err'] = 'Please Enter Email';
                }

                // Validite password
                if(empty($data['password'])){
                    $data['password_err'] = 'Please Enter Password';
                }

                // Check for user/email
                if($this->userModel->findUserByEmail($data['email'])){
                    // User found
                } else {
                    // User not found
                    $data['email_err'] = 'No user found';
                }

                // Make sure errors are empty
                if(empty($data['email_err']) && empty($data['password_err'])){
                    // Validated
                    // Check and set logged in user
                    $loggedInUser = $this->userModel->login($data['email'], $data['password']);

                    if($loggedInUser){
                        // Create Session
                        $this->createUserSession($loggedInUser);
                    } else {
                        $data['password_err'] = 'Password incorrect';
                        $this->view('users/login', $data);
                    }
                } else {
                    // Load view with errors
                    $this->view('users/login', $data);
                }

            } else {
                // Init data
                $data = [
                    'email'         => '',
                    'password'      => '',
                    'email_err'     => '',
                    'password_err'  => ''
                ];

                // Load form
               $this->view('users/login', $data);
            }
        }


        public function createUserSession($user){
            $_SESSION['user_id']        = $user->id;
            $_SESSION['user_name']      = $user->name;
            $_SESSION['user_email']     = $user->email;
           $_SESSION['user_country']   = $user->country;
			$_SESSION['user_roles']   = $user->role;
			
            redirect('pages/index');
        }

        public function logout(){
            unset($_SESSION['user_id']);
            unset($_SESSION['user_name']);
            unset($_SESSION['user_email']);
            unset($_SESSION['user_country']);
            session_destroy();
            redirect('users/login');
        }

        public function isLoggedIn(){
            if(isset($_SESSION['user_id'])){
                return true;
            } else {
                return false;
            }
        }
public function listdisplay()
	{
	$seledate = date('m/d/Y',strtotime("-0 days"));
//	echo "=====".$seledate;
		// $sdate=$_REQUEST['sdate'];
		$sdate = date('Y-m-d', strtotime($_REQUEST['sdate']));
	
		if($sdate!='')
		{
			//print_r("sghalui".$datelist);
		//$obj = new currentstatus();
		//$obj->db=$this->registry->db;
		//$listqry=$this->db->query("SELECT * FROM users WHERE date = ".$sdate."");
		$datelist= $this->userModel->getData($sdate);
		//print_r($datelist);
		//echo "sandy".$listqry."=====";
		 //$listqry=$obj->selectqry($datelist);
	// $listarr= $listqry->fetchAll(PDO::FETCH_ASSOC);	
		 $j=0;
		 // print_r($listarr);exit;
		 foreach($datelist as $value)
			{
			// echo $value->duration;
			 //print_r($value);
			 //print_r($value['duration']);
			$succlist[$j]['seldate']=$sdate;
			$succlist[$j]['time_id']=$value->time_id;
			$succlist[$j]['project_name']=$value->project_name;
			$succlist[$j]['start_time']=$value->start_time;
			$succlist[$j]['end_time']=$value->end_time;
			
			$succlist[$j]['duration']=$value->duration;
			$succlist[$j]['notes']=$value->notes;
			$succlist[$j]['work_status']=$value->work_status;
			//$listarr[$j]['notes']=$value['notes'];
			//$datelist[$j]['prname']=$value['projectname'];		
			//$datelist[$j]['acttime']=$value['acttime'];
			$sumdurarr[$j]=$value->duration;
			$j++;
			} 
			// print_r($listarr);exit;
		 $sumdur=$this->sum_time($sumdurarr);	
		 $listtotarr = array($succlist,$sumdur);	
		//print_r($listtotarr);
		 echo json_encode($listtotarr);
		}
	}

	public function deletelog()
	{
	$sdate=$_REQUEST['sdate'];
	$sdate=str_replace('/','-',$sdate);
	$sdate  = date("Y-m-d", strtotime($sdate));
	$delid=$_REQUEST['delid'];
	$delqry = $this->userModel->deletedata($delid);

	//$obj = new currentstatus();
	//$obj->db=$this->registry->db;
	//$delqry="DELETE FROM mis_taskassign_log WHERE mtl_activestatus='0' and mtl_id='".$delid."'";
	//$delqry=$obj->updateqry($delqry);
	echo $delqry;
	}

public function editlog()
	{
	$editid=$_REQUEST['editid'];
	//print_r("SELECT * FROM `time_tracker` WHERE time_id='".$editid."'");
	//echo "sss".$editid;
	//$obj = new currentstatus();
	//$obj->db=$this->registry->db;
	$listqry=$this->userModel->editdata($editid);
	//print_r($listqry);
	//echo "sandy".$listqry."===";
// print_r($listarr);exit;	 
	 $j=0;
	 foreach($listqry as $value)
		{
		//$succlist[$j]['seldate']=$sdate;
			$succlist[$j]['time_id']=$value->time_id;
			$succlist[$j]['project_name']=$value->project_name;
			$succlist[$j]['start_time']=$value->start_time;
			$succlist[$j]['end_time']=$value->end_time;
			
			$succlist[$j]['notes']=$value->notes;
			$succlist[$j]['work_status']=$value->work_status;
			//$listarr[$j]['notes']=$value['notes'];
			//$datelist[$j]['prname']=$value['projectname'];		
			//$datelist[$j]['acttime']=$value['acttime'];
			$j++;
		}
	echo json_encode($listqry);	
	}
	//23/03
	public function edittask(){
	$sdate = date('Y-m-d', strtotime($_REQUEST['sdate']));
		$timetrackid=$_REQUEST['timetrackid'];
		$eproject=$_REQUEST['eproject'];
		
		$estarttime=$_REQUEST['estarttime'];
		$estarttime=$estarttime.':00';
		$eendtime=$_REQUEST['eendtime'];
		$eendtime=$eendtime.':00';
		$enote=$_REQUEST['edescription'];
	}

	public function sum_time($timelist)
	{
		$j = 0;
		for ($i=0;$i<count($timelist);$i++)
		{
		sscanf($timelist[$i], '%d:%d', $hour, $min);
		$j += $hour * 60 + $min;
		}
		if ($h = floor($j / 60)) {
		$j %= 60;
		}
		return sprintf('%02d:%02d', $h, $j);
	}

	//shalini 13/03
	public function timetrackercntrl(){
            // Chech for POST
			$seledate = date('m/d/Y',strtotime("-0 days"));
		//	$SESSION[$seledate];

            if($_SERVER['REQUEST_METHOD'] == 'POST'){

                // Process form
				//$c_date=$_SESSION['sdate'];

                // Sanitize POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
				$sdate = date('Y-m-d', strtotime($_REQUEST['sdate']));
				$starttime=$_REQUEST['starttime'];
				$starttime=$starttime.':00';
				$endtime=$_POST['endtime'];
				$endtime=$endtime.':00';
				$stdate=$sdate.' '.$starttime;
				$endate=$sdate.' '.$endtime;	

							/*	if(isset($_REQUEST['starttime']))
									{
						// Access the value of 'name' field
						$name = $stdate;

						// Now you can use $name as needed, for example:
						echo "The name submitted is: " . $name;
						echo "<br>";
						echo $_POST['endtime'];
						echo "<br>";
						echo $endate;
					} else {
						echo "Name field is not set in the form submission.";
					}*/

                $data = [
				    'user_id' => $_SESSION['user_id'],
					'date'                  => trim($_POST['sdate']),
                    'projectid'                  => trim($_POST['projectid']),
                    'worktype'                 => trim($_POST['worktype']),
                    'starttime'              => $stdate,
                    'endtime'      => $endate,
                    'note'               => trim($_POST['description']),
					'workstatus'  =>trim($_POST['workstatus'])
       ];

/*if($this->userModel->timetracker($data)){
                        flash('register_success', 'You are registered and can log in');
                        redirect('users/timetracker');
                    } else {
                        die('Something went wrong');
                    }*/
				if ($this->userModel->timetracker($data)) {
    // If insertion is successful, fetch last inserted data
   // $lastInsertedData = $this->userModel->getLastInsertedData($stdate);
   
 /*   if (isset($lastInsertedData)) {
     
		$this->view('users/timetracker', $lastInsertedData);
		
    } else {
        $this->view('users/timetracker');
    } */
    redirect('users/timetracker');
} else {
    // If insertion fails, display error message
    die('Something went wrong');
}

				} else 
				{
                // Init data
                $data = [
                    'user_id'                  => '',
                    'projectid'                 => '',
                    'worktype'              => '',
                    'starttime'      => '',
                    'endtime'               => '',
                    'note'              => '',
                    'workstatus'             => ''
                ];

                // Load view
                $this->view('users/timetracker');
            }
        }


        public function addNewUser(){
            // Check for post
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                // Process form
                // Sanitize POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                // Init data	
                $data = [
                    'name'      => trim($_POST['name']),
                    'email'     => trim($_POST['email']),
                    'password'  => trim($_POST['password']),
                    'country'   => trim($_POST['country']),
                    'role'      => $_POST['role'],
                    'email_err' => ''
                ];

                // Validite Name
                if(empty($data['name'])){
                    $data['name_err'] = 'Please Enter Name';
                }

                // Validite Email
                if(empty($data['email'])){
                    $data['email_err'] = 'Please Enter Email';
                } else {
                    // Check Email
                    if($this->userModel->findUserByEmail($data['email'])){
                        $data['email_err'] = 'Email is already taken';
                    }
                }

                // Validite Password
                if(empty($data['password'])){
                    $data['password_err'] = 'Please Enter Password';
                } elseif(strlen($data['password']) < 6){
                    $data['password_err'] = 'Password must be at least 6 characters';
                }

                // Validate Country
                if(empty($data['country'])){
                    $data['country_err'] = 'Please Enter Country';
                }

                // Make sure errors are empty
                if(empty($data['email_err'])){
                    // Hash passowrd
                    //$data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
					$data['password'] = $data['password'];

                    // Add user
                    if($this->userModel->adduser($data)) {
                        flash('add_success', 'User added');
                        redirect('users/users');
                    } else {
                        die('something went wrong');
                    }
                } else {
                    // Load view with errors
                    return $data;
                }
            } else {
                // Init data
                $data =[
                    'name'      => '',
                    'email'     => '',
                    'password'  => '',
                    'country'   => '',
                    'role'      => '',
                    'email_err' => ''
                ];

                 // Load view
                 return $data;
            }
        }

        public function edit($id){
            // Check for post
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                // Process form
                // Sanitize POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                // Init data
                $data = [
                    'id'        => $id,
                    'name'      => trim($_POST['name']),
                    'email'     => trim($_POST['email']),
                    'password'  => trim($_POST['password']),
                    'country'   => trim($_POST['country']),
                    'role'      => $_POST['role'],
                    'email_err' => ''
                ];

                // Validite Email
                if(empty($data['email'])){
                    $data['email_err'] = 'Please Enter Email';
                } else {
                    // Check Email
                    if($this->userModel->findUserByEmail($data['email'])){
                        $data['email_err'] = 'Email is already taken';
                    }
                }

                // Validite Password
                if(strlen($data['password']) < 6){
                    $data['password_err'] = 'Password must be at least 6 characters';
                }

                // Make sure errors are empty
                if(empty($data['email_err'])){
                    // Hash passowrd
                   // $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
				   $data['password'] = $data['password'];
				  
                    // Update user
                    if($this->userModel->updateUser($data)) {
                        flash('add_success', 'User Updated');
                        redirect('users/users');
                    } else {
                        die('something went wrong');
                    }
                } else {
                    // Load view with errors
                    $this->view('users/edit', $data);
                }
            } else {

                // Get current page for active navigation class
                $link = URLROOT.$_SERVER['REQUEST_URI'];
                $pieces = explode("/", $link);
                $last = array_pop($pieces);

                $user = $this->userModel->getUserById($id);

                // Init data
                $data = [
                    'link'      => $last,
                    'id'        => $id,
                    'name'      => $user->name,
                    'email'     => $user->email,
                    'password'  => $user->password,
                    'country'   => $user->country,
                    'role'      => $user->role
                ];
                $this->view('users/edit', $data);
            }


        }

        public function delete($id){
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                 //get existing post from model
                 $user = $this->userModel->getUserById($id);



                if($this->userModel->deleteUser($id)){
                    flash('user_message', 'user Removed');
                    redirect('users');
                }else{
                    die('something went wrong');
                }
            }else{
                redirect('users');
            }
        }
    }