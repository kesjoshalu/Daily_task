<?php
class currentstatus
{
public function selectqry($qry)
	{
		$selectqry = $qry;
		$status = $this->db->query($selectqry);
		return $status;
	}
public function updateqry($qry)
	{
		$selectqry = $qry;
		$status = $this->db->query($selectqry);
		return 1;
	}	
public function insertqry($qry)
	{
		$selectqry = $qry;
		$status = $this->db->query($selectqry);
		return 1;
	}	
}
?>