
    </div>
</div>

<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
  <script src="<?= URLROOT; ?>/js/bootstrap.min.js"></script>

<!-- Resources -->
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>


<script src="<?= URLROOT; ?>/js/main.js"></script>
<script src="<?= URLROOT; ?>/js/rolesDataChart.js"></script>

<script>

</script>


</body>
</html>