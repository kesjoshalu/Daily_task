<?php
print_r($data['user']);