

<?php require APPROOT . '/views/inc/header.php'; ?>

<?php require APPROOT . '/views/inc/sidebar.php'; ?>
<?php

// Set current date in session
$_SESSION['current_date'] = date("Y-m-d");

// Render HTML page
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap -->

<link rel="stylesheet" href="<?= URLROOT; ?>/css/style.css">
    <link rel="stylesheet" href="<?= URLROOT; ?>/css/bootstrap.min.css">
	<!-- <link rel="stylesheet" href="<?= URLROOT; ?>/css/bootstrap-select.css"> -->

<link href="styles/main.css" rel="stylesheet">
<link href="styles/media.css" rel="stylesheet">
<link href="styles/font-awesome.css" rel="stylesheet" type="text/css">
<link href="styles/bootstrap-select.css" rel="stylesheet">
<link href="styles/datepicker.css"  rel="stylesheet">
<link rel="stylesheet" href="styles/chart_style.css" type="text/css">
<link rel="stylesheet" href="styles/bootstrap.minzz.css">
<!-- <link rel="stylesheet" href="<?= URLROOT; ?>/css/bootstrap.minzz.css"> -->

<style>

.table-bordered {
 background-color: #2e3458;
 }
 .table-striped th{
    color: white;
	/* background-color:white; */

}
.time-tbl-cnt,tfoot tr{
background-color:white; 
}

.card {
        margin: 0 auto; /* Added */
        float: none; /* Added */
		margin-left: 250px; /* Added */
        margin-bottom: 10px; /* Added */

}
.btn-primary{
background-color: #eee;
color: black;
}
.edit-time
{font-size:16px;color:#2e3458;}

.modal-body {
  position: relative;
  padding: 15px;
}
.panel-heading.form-panel-head {
  color: #333;
  background-color: #f5f5f5;
  border-color: #ddd;
  padding:10px; 
  /*! font-size: 50px; */
}
.panel-body {
 padding:15px;
}
.atten-time-scroll{height:calc(100vh - 170px);overflow:auto;overflow-x:hidden;}


</style>
<body>
<!-- <?php
//echo "date".$c_date;
echo $_SESSION['sdate'];
?> -->
<div id="wrapper" class="d-board-Bg">
  <!---------18-04-2020--start------>	
  <div class="navbar-fixed-top pos-stat">
    <nav class="navbar navbar-static-top head1">
      <div class="container-fluid">
        <!-- <div class="navbar-header"> <a href="dashboard.html" class="navbar-brand"><img src="images/logo.png"></a>
          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div> -->
       
      </div>
    </nav>
  </div>

  
<div class="card">
<!-- <?php "echo".$value;?> -->

  <div id="page-wrapper" class="pad-b0" style=" min-height: 420px;">
    <div class="right-panel">
      <div class="content-main">
        <div class="row justify-content-center">
          <div class="col-md-12">
            <div class="panel panel-default form-page mrgn-btm0">
              <div class="panel-heading form-panel-head">
                <h4>Time Track </h4>
				
              </div>


			  <div class="panel-body">
                <div class="atten-time-scroll">
                  <div class="row">
                    <div class="col-md-3">
                      <form action="<?php echo URLROOT; ?>/users/timetracker" class="form-horizontal form-Rinput"  method="post">
                        <!-- Form content here -->
						<div class="form-group">
								<label class="col-md control-label">Date</label>
								 <div class="col-md">
								   
								   <div id="sandbox-container">
									  <div id="datepicker" class="input-daterange">
										<div class="input-group">
										  <input placeholder="" id="sdate" name="sdate" class="form-control input-sm" type="date" value="<?php echo $_SESSION['current_date']; ?>">
									  <!-- <span class="input-group-addon"><i class="fa fa-calendar"></i></span> --> </div>
									  </div>
									</div>
									
								</div>
							</div>
						
							 <div class="form-group">
							<label for="inputPassword3" class="col-md control-label">Project Name</label>
							<div class="col-md">
							   <select id="project" name="project" class="selectpicker show-tick form-control" data-live-search="false">
							   <option value="0">Select Project</option>
							   <option value="1">Mpigrs</option>
							   <option value="2">Mod</option>
							   <option value="3">Jstore</option>
							   <option value="4">Federal</option>
							    <option value="5">Coc</option>
							
								</select>
							</div>
						  </div>
							
							<div class="form-group">
							<label for="inputPassword3" class="col-md control-label">Work Type</label>
								<div class="col-md-4">
								<div class="form-check-inline">
											<label class="customradio"><span class="radiotextsty">Support</span>
											  <input name="worktype" type="radio" name="radio" value="Support">
											  <span class="checkmark"></span>
											</label> 
											<label class="customradio"><span class="radiotextsty">Development</span>
											  <input name="worktype" type="radio" checked="checked" name="radio" value="Development">
											  <span class="checkmark"></span>
											</label>
										</div>
								
								</div>
							</div>
						 
							
							<div class="form-group">
								<label for="inputPassword3" class="col-md-6 control-label">Start Time
								</label>
								<!-- <div class="col-md-8">
								<input id="starttime" placeholder="HH:MM" class="time-inpt input-sm col-md-8" type="text">
									<button type="button" class="btn btn-primery btn-sm time-nowbtn col-md-4 currenttime" id="startnow" value="NOW" > Now</button>
								
								</div> -->
							<div class="col-md">
								<div class="row">
									<div class="col-md-9">
										<input id="starttime" placeholder="HH:MM" class="time-inpt input-sm" type="text">
									</div>
									<div class="col-md-3">
										<button type="button" class="btn btn-primary btn-sm currenttime" id="startnow" value="NOW">Now</button>
									</div>
								</div>
							</div>

						    </div>
							
							<div class="form-group">
								<label for="inputPassword3" class="col-md-6 control-label">End Time
								</label>
								<div class="col-md">
									<div class="row">
										<div class="col-md-9">
											<input placeholder="HH:MM" class="time-inpt input-sm" id="endtime" type="text">
										</div>
										<div class="col-md-3">
											<button type="button" class="btn btn-primary btn-sm time-nowbtn" id="endnow">Now</button>
										</div>
									</div>
								</div>

							</div>
							
							<div class="form-group">
							<label for="inputPassword3" class="col-md control-label">Notes</label>
								<div class="col-md">
									<textarea  id="description" class="form-control input-sm" rows="2"></textarea>
								</div>
								
							</div>
							<div class="form-group">
							<label for="inputPassword3" class="col-md control-label">Work Status</label>
								<div class="col-md">
								<div class="form-check-inline">
											<label class="customradio"><span class="radiotextsty">Completed</span>
											  <input name="workstatus" type="radio" name="radio" value="Completed">
											  <span class="checkmark"></span>
											</label> 
											<label class="customradio"><span class="radiotextsty">WIP</span>
											  <input name="workstatus" type="radio" checked="checked" name="radio" value="WIP">
											  <span class="checkmark"></span>
											</label>
										</div>
								
								</div>
							</div>
							
							<div class="form-group">
								<div class="col-md-12 text-center">
								 <button type='button' class="btn btn-success btn-sm " id='addnew'> Add </button>
								</div>
							</div>
							
                      </form>
                    </div>
                    <div class="col-md-8">
                      <div class="table-responsive" id="tableshow">
                        <table id="esttime" class="table table-bordered table-panel table-striped">
                          <!-- Table content here -->
						  <thead><tr><th colspan="9" style="text-align:center">Select Date is : <span><?php $sdate; ?></span></th></tr><tr class="time-tblbg"><th style="text-align:center">S.No</th><th style="text-align:center">Project Name</th> <th style="text-align:center">Start  Time</th><th style="text-align:center">End Time</th><th style="text-align:center">Duration</th><th style="text-align:center" width="50%">Notes</th><th style="text-align:center">Edit</th><th style="text-align:center">Delete</th></tr></thead>
							
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


	<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header pop-header-txtclr">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Assign Task</h4>
      </div>
      <div class="modal-body">
		  
		  		<form class="form-horizontal">
						  <div class="form-group">
							<label for="inputPassword3" class="col-md-3 control-label">Technology:</label>
							<div class="col-md-7">
							   <select id="basic" class="selectpicker show-tick form-control" data-live-search="false">
								  <option value="Select">PHP</option>
								  <option value="Apparel">JAVA</option>
								  <option value="Hospitality">JavaScript</option>
								  <option value="Insurance">C</option>
								</select>
							</div>
						  </div>
					
					<div class="form-group">
								<label for="inputPassword3" class="col-md-3 control-label">Estimation Effort:
								</label>
								<div class="col-md-7">
								<input placeholder="HH:MM" class="form-control input-sm" type="text">
									
								</div>
						    </div>
					
					<div class="form-group">
								<label for="inputPassword3" class="col-md-3 control-label">Plan Start Datetime:
								</label>
								<div class="col-md-7">
								<input placeholder="YYYY-MM-DD HH:MM" class="time-inpt input-sm col-md-8" type="text">
									<button class="btn btn-primery btn-sm col-md-4 time-nowbtn-pop"> Now</button>
								</div>
						    </div>
					
					     <div class="form-group">
								<label for="inputPassword3" class="col-md-3 control-label">Plan End Datetime:
								</label>
								<div class="col-md-7">
								<input placeholder="YYYY-MM-DD HH:MM" class="time-inpt input-sm col-md-8" type="text">
									<button class="btn btn-primery btn-sm col-md-4 time-nowbtn-pop"> Now</button>
								</div>
						    </div>
					
					<div class="form-group">
							<label for="inputPassword3" class="col-md-3 control-label">Task Description</label>
								<div class="col-md-7">
									<textarea class="form-control input-sm" rows="2"></textarea>
								</div>
					</div>
					
		  </form>
      </div>
      <div class="modal-footer text-center">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success">Save changes</button>
      </div>
    </div>
  </div>
</div>
	
	<!--   For Editing -->
	<div class="modal fade" id="editdiv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header pop-header-txtclr">
		  <h5 class="modal-title" id="myModalLabel">Edit Task</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<!-- <h4 class="modal-title" id="myModalLabel">Edit Task</h4> -->

		  </div>
		  <div class="modal-body">
			  
					<form class="form-horizontal">
						<div id="editlist123" class="form-group">
								<div class="form-group row">
		<label for="inputPassword3" class="col-md-4 control-label">Project Name:</label>
			<div class="col-md-7">
				 <select id="editprojectlit" class="selectpicker show-tick form-control" data-live-search="false">
				 </select>
			</div>
				<input type="hidden" id="timetrackid" value="2">
	</div>
						
							
							<div class="form-group row">
								<label for="inputPassword3" class="col-md-4 control-label">Start Time:
								</label>
								<div class="col-md-7">
								<input id="editstartime" placeholder="HH:MM" class="time-inpt input-sm" type="text">
									<button type="button" class="btn btn-primery btn-sm time-nowbtn-pop" id="editstartnow" value="NOW"> Now</button>
								</div>
							</div>
						
							<div class="form-group row">
								<label for="inputPassword3" class="col-md-4 control-label">End Time:
								</label>
								<div class="col-md-7">
								<input id="editendtime" placeholder="HH:MM" class="time-inpt input-sm" type="text">
									<button type="button" id="editendnow" value="NOW" class="btn btn-primery btn-sm time-nowbtn-pop"> Now</button>
								</div>
							</div>
						
							<div class="form-group row">
								<label for="inputPassword3" class="col-md-4 control-label">Task Description</label>
								<div class="col-md-7">
									<textarea id="editnotes" class="form-control input-sm" rows="2"></textarea>
								</div>
							</div>
						</div>
						
					</form>
		  </div>
		  <div class="modal-footer text-center">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			<button type="button" class="btn btn-success" id="editSave">Save changes</button>
		  </div>
		</div>
	  </div>
	</div>
	<input type="hidden" id="deleteid">
	<div class="modal fade" id="deletediv" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-header pop-header-txtclr">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Delete Task</h4>
		  </div>
		  <div class="modal-body">
				<span class="pop-dlt">Are You sure want to Delete the Record.</span>
		  </div>
		  <div class="modal-footer text-center">
			<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
			<button type="button" class="btn btn-success" id="deleteSave">Yes</button>
		  </div>
		</div>
	  </div>
	</div>
	<!--   For Editing -->
	
</div>

<style>
.cursor-pointer{
  cursor: pointer;

}
</style>
<!-- jQuery -->

<script src="scripts/jquery.js"></script>
<script src="scripts/leftmenu.js"></script>
<!-- <?php include('geturl.php');?> -->
<script src="scripts/bootstrap.min.js"></script>
<script src="scripts/menu.js"></script>
<script src="scripts/window-height.js"></script>
<script src="scripts/uitility.js"></script>
<script src="scripts/bootstrap-datepicker.js"></script>
<script src="scripts/bootstrap-select.js"></script>
<script src="amcharts/amcharts.js" type="text/javascript"></script>
<script src="amcharts/pie.js" type="text/javascript"></script>
<script src="amcharts/themes/light.js" type="text/javascript"></script>
<script src="amcharts/serial.js" type="text/javascript"></script>
<script src="scripts/default.js"></script>
<script src="scripts/nano.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!--<script src="scripts/timetracker.js"></script>-->

<script>
    $(document).ready(function() {
        $('#startnow').click(function() {
            var stime = currenttime();
            document.getElementById("starttime").value = stime;
        });

        $('#endnow').click(function() {
            var stime = currenttime();
            document.getElementById("endtime").value = stime;
        });

        // Define your currenttime() function here if it's not defined already
        function currenttime()
{
	
		var d = new Date(); 
		var date =d.getDate();
		var month =d.getMonth()+1;
		var year =d.getFullYear();
		var hr=d.getHours(); 
		var min=d.getMinutes(); 
		var seconds =d.getSeconds();
		var dat="'";
		dat+=date;
		dat+="'";
		var datt =dat.charAt(2);
		 if(datt!="'")
		{
		date=date;
		}
		else{
		date='0'+date;
		}
		var mon="'";
		mon+=month;
		mon+="'";
		var mont =mon.charAt(2);
		 if(mont!="'")
		{
		month=month;
		}
		else{
		month='0'+month;
		}
		var mins="'";
		mins+=min;
		mins+="'";
		var minss =mins.charAt(2);
		 if(minss!="'")
		{
		min=min;
		}
		else{
		min='0'+min;
		}
		var sec="'";
		sec+=seconds;
		sec+="'";
		var secs =sec.charAt(2);
		 if(secs!="'")
		{
		seconds=seconds;
		}
		else{
		seconds='0'+seconds;
		}
		var hrs="'";
		hrs+=hr;
		hrs+="'";
		var hrs =hrs.charAt(2);
		 if(hrs!="'")
		{
		hr=hr;
		}
		else{
		hr='0'+hr;
		}
		var datehrminsec=year+'-'+month+'-'+date+" "+hr+":"+min+":"+seconds;
		var datehrmin=hr+":"+min;
		return datehrmin;
		// document.getElementById("editstartime").value = datehrmin;
		//$('#starttime').val(datehrmin);					
}

   });
$("#sdate").change(function(){
	tablelisting()
});
function tablelisting()
{
	// $('.modal-content').css('display','none');
	$('#starttime').val('');
   $('#endtime').val('');
   $('#description').val('');
	var ajaxurl = "<?php echo URLROOT;?>/Users/listdisplay";
	var tablelist;
	var sdate=$("#sdate").val();//alert(sdate)
	$.ajax({ 
		url: ajaxurl,
		dataType: "json",
		type: 'post',
		data:{sdate:sdate}, 
		success: function(response)
		{	
           var sno=1;
		   var res=response[0]; //alert(res)
		    
		   var totdur=response[1];//<!--<th style='text-align:center'>Module Name</th>-->
		  var tablelist="<thead><tr><th colspan='9' style='text-align:center'>Select Date is : <span>"+sdate+"</span></th></tr><tr class='time-tblbg'><th style='text-align:center'>S.No</th><th style='text-align:center'>Project Name</th> <th style='text-align:center'>Start  Time</th><th style='text-align:center'>End Time</th><th style='text-align:center'>Duration</th><th  style='text-align:center' width='50%'>Notes</th><th  style='text-align:center'>Work Status</th><th style='text-align:center'>Edit</th><th style='text-align:center'>Delete</th></tr></thead><tbody class='time-tbl-cnt'>";
		  //alert(res)
		   if(res!='')
           {		   
		   $.each(res, function(ke, value ) {

			tablelist+='<tr><td>'+sno+'</td>';			
			tablelist+='<td>'+value['project_name']+'</td>';
			// tablelist+='<td>'+value['mname']+'</td>';
			tablelist+='<td>'+value['start_time']+'</td>';
			tablelist+='<td>'+value['end_time']+'</td>';
			tablelist+='<td>'+value['duration'].substring(0,5)+'</td>';
			tablelist+='<td>'+value['notes']+'</td>';
			
			tablelist+='<td>'+value['project_name']+'</td>';
			if(value['ttrackrecod']!=0)
			{
				// tablelist+='<td width="20%"><span style="cursor:pointer;" onclick="editdetails('+value['timetrackid']+')"><img src="images/keywordedit.png" width="20%" height="15%"></span></td>';
				tablelist+='<td width="20%"><a data-toggle="modal" data-target="#editdiv" href="#"><span onclick="editdetails('+value['time_id']+')" class="glyphicon glyphicon-pencil edit-time"><i class="fas fa-pen p-1"></i></span></a></td>';
				// tablelist+='<td width="20%"><span style="cursor:pointer;" onclick="deliddetails('+value['timetrackid']+')"><img src="images/keyworddelete.png" width="20%" height="15%"></span></td></tr>';
				tablelist+='<td width="20%"><a data-toggle="modal" data-target="#deletediv" href="#" onclick="deliddetails('+value['time_id']+')" class="time-trash" href="#"><i class="fa fa-trash"></i></a></tr>';
			}else{
				// tablelist+='<td width="20%"><span style="cursor:pointer;" onclick="editdetails('+value['timetrackid']+')"><img src="images/keywordedit.png" width="20%" height="15%"></span></td>';
				tablelist+='<td width="20%"><a data-toggle="modal" data-target="#editdiv" href="#"><span onclick="editdetails('+value['time_id']+')" class="glyphicon glyphicon-pencil edit-time"><i class="fas fa-pen p-1"></i></span></a></td>';
				// tablelist+='<td width="20%"><span style="cursor:pointer;" onclick="deliddetails('+value['timetrackid']+')"><img src="images/keyworddelete.png" width="20%" height="15%"></span></td></tr>';
				tablelist+='<td width="20%"><a data-toggle="modal" data-target="#deletediv" onclick="deliddetails('+value['time_id']+')" class="time-trash" href="#"><i class="fa fa-trash"></i></a></tr>';
			}
			sno++;
			});
			tablelist+='</tbody class="time-tbl-cnt"><tfoot><td colspan="4">Total</td><td>'+totdur+'</td><td></td><td></td><td></td><td></td></tfoot>';
			$('#esttime').html(tablelist);
            }else{
            tablelist+='<tbody class="time-tbl-cnt"><tr><td colspan="10">No Records Found</td></tr></tbody>';
		    $("#esttime").html(tablelist);
			}			
		}
    });
}

function editdetails(editid)
{ 
	// $('.modal-content').css('display','block');
	$("#list").html("Edit");	
 	$("#editlist").html('<div class="loading"></div>');
	var readonly;
	var ajaxurl = "<?php echo URLROOT;?>/Users/editlog";
	$.ajax({ 
		url: ajaxurl,
		dataType: "json",
		type: 'post',
		data:{editid:editid}, 
		success: function(response)
		{
			//alert(response)
			if(response!='')
			{
				//alert("succ")
				// modulelist(response[0]['projectid'],response[0]['moduleid']);
				var notecr = response[0]['notes'].split('-');
				//alert(notecr)
				var flagdes = 1;
				
				if(notecr[0]==undefined || notecr[1]==undefined)
				{
					var notedesc = notecr[0];
					flagdes = 2;
				}
				else
				{
					var notedesc = notecr[1];
					flagdes = 1;
					readonly = "disabled=false";
				}
				//alert(notedesc)
				//projectlist(response[0]['project_name']);
				// var ttttime = '2020-06-18 10:13';
				//alert(response[0]['start_time'])
				$('#editstartime').val(response[0]['start_time'].substring(11,16));
				$('#editendtime').val(response[0]['end_time'].substring(11,16));
				$('#timetrackid').val(editid);
				$('#editnotes').html(notedesc);
			}		
		}
		});
}

function deliddetails(delid)
{
	$('#deleteid').val(delid);
}
$('#deleteSave').click(function()
{
	var delid = $('#deleteid').val();
	var ajaxurl = "<?php echo URLROOT;?>/Users/deletelog";
	var tablelist;
	var sdate=$("#sdate").val();
	$.ajax({ 
		url: ajaxurl,
		dataType: "json",
		type: 'post',
		data:{sdate:sdate,delid:delid}, 
		success: function(response)
		{
			$('#deletediv').modal('hide');
          	if(response == 1)
			{
				tablelisting();
				alert("deleted successfully");
			}else
			{
				alert("Data Deleted Failed");
			}
		}
     });
});
$('#editSave').click(function()
{
	var timetrackid = $('#timetrackid').val();
	// alert(timetrackid)
  var sdate=$("#sdate").val();
  var eproject=$("#editprojectlit").val();
  // var emodule=$("#modulelist").val();
  var estarttime=$("#editstartime").val();
  var eendtime=$("#editendtime").val();
  var edescription=$("#editnotes").val();
  var ehrsformat=/^(00|0[0-9]|1[0-9]|2[0-3]):(0[0-9]|[0-5][0-9])$/g;
  // var checstatus=$('[name="checkendpop"]:checked').val();
  var endconfirm = true;                      
	var checstatus = 4;
  var echeck=1;
  if(project==0)
  {
   alert("Kindly Select the Project")
   echeck=0;
  }
  else if(estarttime=='')
  {
   alert("Kindly check Starttime is Empty")
   echeck=0;
  }
  else if(!estarttime.match(ehrsformat))
  {  
  alert("Kindly Enter Starttime Format Correctly(HH:MM)");						 
  echeck=0;
  }	
  else if(eendtime=='')
  {
   alert("Kindly check Endtime is Empty")
   echeck=0;
  }
  else if(!eendtime.match(ehrsformat))
  {    
  alert("Kindly Enter Endtime Format Correctly(HH:MM)");						 
  echeck=0;
  }	
  else if(estarttime==eendtime)
  {
  alert("Kindly check,Start datetime and End datetime are same");
  echeck=0;  
  }
  else if(estarttime>eendtime)
	{
	alert("Kindly check,Start time should not greater than End time");
	echeck=0;  
	}
  else if(edescription=='')
  {
    alert("Kindly Check Description is Empty")
   echeck=0;
  }
  if(echeck==1 && endconfirm==true)
  {
  	
	var ajaxurl = "index.php?rt=timetrack/updatetimelog";
	$.ajax({ 
		url: ajaxurl,
		dataType: "json",
		type: 'post',
		data:{sdate:sdate,timetrackid:timetrackid,eproject:eproject,estarttime:estarttime,eendtime:eendtime,edescription:edescription,checkstatus:checstatus}, 
		success: function(response)
		{
			/* if(response == 1)
			{
				$('#editdiv').modal('hide');
				tablelisting();
			}else if(response == 0) 
			{
				alert("Data is not Updated");
			} */
			
			if(response!=1)
			{
			   if(response!=7)
			   {
				   if(response!=2)
				   {
					   if(response!=3)
					   {
						   if(response!=4)
						   {
								if(response == 10)
								{
									$('#editdiv').modal('hide');
									tablelisting();
								}else if(response == 11) 
								{
									alert("Data is not Updated");
								}
							}else{
							 alert("Kindly check,Time overlap with existing record");
							 $("#cover-spin").css('display','none');
							}
						}else{
						 alert("Kindly check,Endtime overlap with existing record");
						 $("#cover-spin").css('display','none');
						}
					}else{
					 alert("Kindly check,Starttime overlap with existing record");
					 $("#cover-spin").css('display','none');
					}
					
				}
			}else
			{
				 alert("Kindly check,Starttime overlap with existing record");
			}
		}
	});
 }

});


	$("#addnew").click(function(){
	//alert("click");
	//alert($data);
	
	
  var currdate=currentdate(); //alert(currdate)
  var sdate=$("#sdate").val(); //alert(sdate)
 var cdate = console.log(sdate);
  var team=1;
  var project=$("#project").val();
  var module=$("#module").val();//alert(module)
  var starttime=$("#starttime").val();
  var endtime=$("#endtime").val();
  var description=$("#description").val();
  var hrsformat=/^(00|0[0-9]|1[0-9]|2[0-3]):(0[0-9]|[0-5][0-9])$/g;
  var check=1;
  var checkdate=sdate.replace(/\//g, "-"); //alert(checkdate)
  var chkdate=checkdate.split("-"); 
  //var checkdate=chkdate[2]+'-'+chkdate[0]+'-'+chkdate[1]; alert(checkdate);
  var worktype = $('[name="worktype"]:checked').val();//alert(worktype)
  var workstatus = $('[name="workstatus"]:checked').val();//alert(workstatus)
  // var worktype = 1;
  var cr_request = 1;
  // var cr_request = $("#task_ids").val();
 //alert(currdate+"===="+checkdate);return false;
  if(currdate<checkdate)
  {
  alert("Kindly Select the Date Correctly")
  check=0;
  }
  
	if(sdate=='')
	{
		alert("Kindly Check Date is Empty")
		check=0;
	}
  	else if(starttime=='')
	{
		alert("Kindly check Starttime is Empty")
		check=0;
	}
	else if(!starttime.match(hrsformat))
	{                        															                                 
		alert("Kindly Enter Starttime Format Correctly(HH:MM)");						 
		check=0;
	}	
	else if(endtime=='')
	{
		alert("Kindly check Endtime is Empty")
		check=0;
	}
	else if(!endtime.match(hrsformat))
	{                        															                                 
		alert("Kindly Enter Endtime Format Correctly(HH:MM)");						 
		check=0;
	}	
	else if(starttime==endtime)
	{
		alert("Kindly check,Start datetime and End datetime are same");
		check=0;  
	}
	else if(starttime>endtime)
	{
		alert("Kindly check,Start time should not greater than End time");
		check=0;  
	}
	else if(description=='')
	{
		alert("Kindly Check Description is Empty")
		check=0;
	}
	if(check==1)
	{	
		
	var ajaxurl = "<?php echo URLROOT;?>/users/timetrackercntrl";
	var tablelist;
	$.ajax({ 
		url: ajaxurl,
		dataType: "json",
		type: 'post',
		data:{sdate:sdate,starttime:starttime,endtime:endtime,description:description,worktype:worktype,workstatus:workstatus}, 
		success: function(response)
		{   
			console.log(data);
			//alert(response);
		   if(response!=7)
			{
			   if(response!=1)
				{
					if(response!=2)
					{
						if(response!=3)
						{
							if(response!=4)
							{
								if(response==11)
								{
									tablelisting();
								}else
								{
									alert("Data is added Failed");
								}

							}else{
								alert("Kindly check,Time overlap with existing record");
								$("#cover-spin").css('display','none');
							}
						}else{
							alert("Kindly check,Time overlap with existing record");
							$("#cover-spin").css('display','none');
						}
					}else{
						alert("Kindly check,Time overlap with existing record");
						$("#cover-spin").css('display','none');
					}
				}else{
					 alert("Kindly check,Time overlap with existing record");
					 $("#cover-spin").css('display','none');
				}
			}else{
				 alert("Kindly check,Time overlap with existing record");
				 $("#cover-spin").css('display','none');
			}
		}
     }); 
   }  
});

function currentdate()
{
 /* currentdate */
  var d = new Date(); 
		var date =d.getDate();
		var month =d.getMonth()+1;
		var year =d.getFullYear();
		var hr=d.getHours(); 
		var min=d.getMinutes(); 
		var seconds =d.getSeconds();
		var dat="'";
		dat+=date;
		dat+="'";
		var datt =dat.charAt(2);
		 if(datt!="'")
		{
		date=date;
		}
		else{
		date='0'+date;
		}
		var mon="'";
		mon+=month;
		mon+="'";
		var mont =mon.charAt(2);
		 if(mont!="'")
		{
		month=month;
		}
		else{
		month='0'+month;
		}
		var mins="'";
		mins+=min;
		mins+="'";
		var minss =mins.charAt(2);
		 if(minss!="'")
		{
		min=min;
		}
		else{
		min='0'+min;
		}
		var sec="'";
		sec+=seconds;
		sec+="'";
		var secs =sec.charAt(2);
		 if(secs!="'")
		{
		seconds=seconds;
		}
		else{
		seconds='0'+seconds;
		}
		var hrs="'";
		hrs+=hr;
		hrs+="'";
		var hrs =hrs.charAt(2);
		 if(hrs!="'")
		{
		hr=hr;
		}
		else{
		hr='0'+hr;
		}
  var currentdate=year+'-'+month+'-'+date;
  return currentdate;
  /* currentdate */
}
</script>

</body>
<?php require APPROOT . '/views/inc/footer.php'; ?>
</html>