<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/sidebar.php'; ?>

        <div id="main" class="col-md-10">
            <div class="row">
                <div class="col-md-6">
                <canvas id="myChart"></canvas>
                </div>
                <div class="col-md-6">

                </div>
            </div>
        </div>



<?php require APPROOT . '/views/inc/footer.php'; ?>
