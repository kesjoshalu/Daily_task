<?php
    class User {
        private $db;
        private $total_records_per_page = 9;

        public function __construct(){
            $this->db = new Database;
        }

        public function register($data){
            $queryinsert= $this->db->query('INSERT INTO users (name, email, password, country) VALUES (:name, :email, :password, :country)');
			//echo $queryinsert;

            $this->db->bind(':name', $data['name']);
            $this->db->bind(':email', $data['email']);
            $this->db->bind(':password', $data['password']);
            $this->db->bind(':country', $data['country']);
			//$this->db->bind(':role', $data['role']);

            if($this->db->execute()){
                return true;
            } else {
                return false;
            }
        }
		 public function timetracker($data){
           
		   $this->db->query('INSERT INTO time_tracker (user_id,work_date,project_name, work_type , start_time , end_time , notes , work_status ) 
			VALUES  (:id, :date, :project_name, :work_type, :start_time, :end_time, :note, :work_status)');

			  $this->db->bind(':id', $data['user_id']);
            $this->db->bind(':date', $data['date']);
            $this->db->bind(':project_name', $data['projectid']);
            $this->db->bind(':work_type', $data['worktype']);
			$this->db->bind(':start_time', $data['starttime']);
			$this->db->bind(':end_time', $data['endtime']);
			$this->db->bind(':note', $data['note']);
			$this->db->bind(':work_status', $data['workstatus']);

		//	$result = $this->db->execute();

/*if ($result) {
    echo "Insertion successful";
} else {
    echo "Insertion failed: " .  $this->db->errorInfo()[2]; // Display error information
}*/


           if($this->db->execute()){
                return true;
            } else {
                return false;
            }
}

public function deletedata($delid){
	$this->db->query("DELETE FROM time_tracker WHERE time_id='".$delid."'");
	return $this->db->execute();
}
//22/03
public function updatedata(){
$this->db->query("UPDATE time_tracker SET work_date='',project_name='',work_type='',start_time='',end_time='',notes='',work_status='' WHERE time_id=''");
return $this->db->execute();
}

public function editdata($editid){
	$this->db->query("SELECT * FROM `time_tracker` WHERE time_id='".$editid."'");
	//print_r("SELECT * FROM `time_tracker` WHERE time_id='".$editid."'");
	$row = $this->db->resultSet();
		return $row;

}


/*public function getLastInsertedData(){
    $this->db->query("SELECT * FROM time_tracker ORDER BY id DESC LIMIT 1");
	$rows = $this->db->resultSet();
            return $rows;
    //return $this->db->single(); // Assuming single() fetches a single row from the result set
}
*/



public function getData($data){

		$this->db->query("SELECT *,TIMEDIFF(end_time,start_time) as duration FROM time_tracker WHERE work_date = '".$data."'");
		$row = $this->db->resultSet();
		return $row;
}



public function login($email, $password){
            $this->db->query('SELECT * FROM users WHERE email = :email');
            $this->db->bind(':email', $email);

            $row = $this->db->single();

            $hashed_password = $row->password;
			//echo "sha".$hashed_password."fixed===".$password;
			//echo "<br>";
		//	echo "db".$password."======".$password;
            if(password_verify($password, $hashed_password)){
				// $_SESSION['role'] = $row['role'];
				//echo "changed".$hashed_password;
                return $row;
            } else {
                return false;
            }
        }

        public function findUserByEmail($email){
            $this->db->query('SELECT * FROM users WHERE email = :email');
            $this->db->bind(':email', $email);

            $row = $this->db->single();

            return $row;

            //Check row
            if($this->db->rowCount() > 0){
                return true;
            } else {
                return false;
            }
        }

        public  function getAllUsers(){
            $this->db->query("SELECT * FROM users");
            $rows = $this->db->resultSet();
            return $rows;
        }

        public  function getAllUsersLimit(){
            $this->db->query("SELECT * FROM users LIMIT 5");
            $rows = $this->db->resultSet();
            return $rows;
        }

        public function getAllUsersCount(){
            $this->db->query("SELECT COUNT(id) registered_users FROM users");
            $res = $this->db->resultSet();
            return $res;

        }

        public function getCountryCount(){
            $this->db->query("SELECT country, COUNT(country) AS Total FROM users GROUP BY country LIMIT 20");
            $res = $this->db->resultSet();

            $json = json_encode($res);
            file_put_contents(APPROOT . '/data/data.json', $json);

        }
		


        public function getUserRole(){
            $this->db->query("SELECT role, COUNT(role) AS Total FROM users GROUP BY role");
            $res = $this->db->resultSet();
            $json = json_encode($res);
            file_put_contents(APPROOT . '/data/roles.json', $json);
        }

        public function pagination(){
            $data = array();
            // Get page number
            if(isset($_GET['page_no']) && $_GET['page_no']!=""){
                $page_no = $_GET['page_no'];
            } else {
                $page_no = 1;
            }

            // Calculate offset value and set prev and next page variables
            $offset = ($page_no-1) * $this->total_records_per_page;
            $previous_page = $page_no - 1;
            $next_page = $page_no + 1;
            $adjacents = "2";

            // Get total number of pages
            $total_records = $this->countTotalRecords();
            $total_no_of_pages = ceil($this->countTotalRecords() / $this->total_records_per_page);
            $second_last = $total_no_of_pages -1;

            // Fetching limit and offset clause for pagination
            $this->db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT :offset, :total_records_per_page");
            $this->db->bind(':offset', $offset);
            $this->db->bind(':total_records_per_page', $this->total_records_per_page);
            $res = $this->db->resultSet();
            $data = [
                'page_no'           => $page_no,
                'previous'          => $previous_page,
                'next'              => $next_page,
                'total_records'     => $total_records,
                'total_no_of_pages' => $total_no_of_pages,
                'second_last'       => $second_last,
                'user_data'         => $res
            ];
            return $data;

        }

        // Get total records
        public function countTotalRecords(){
            $this->db->query("SELECT COUNT(*) AS total_records FROM users");
            $res = $this->db->resultSet();
            $total_records = $res[0]->total_records;
            return $total_records;
        }

        public function getUserById($id){
            $this->db->query("SELECT * FROM users WHERE id = :id");
            $this->db->bind(':id', $id);
            $row = $this->db->single();
			//$_SESSION['user_role'] = $row['role'];

            return $row;
        }

        public function adduser($data){
            $this->db->query('INSERT INTO users (name, email, password, country, role) VALUES (:name, :email, :password, :country, :role)');

            $this->db->bind(':name', $data['name']);
            $this->db->bind(':email', $data['email']);
            $this->db->bind(':password', $data['password']);
            $this->db->bind(':country', $data['country']);
            $this->db->bind(':role', $data['role']);

            if($this->db->execute()){
                return true;
            } else {
                return false;
            }
        }

        public function updateUser($data){
            $this->db->query("UPDATE users SET name = :name, email = :email, password = :password, country = :country, role = :role WHERE id = :id");

            $this->db->bind(':id', $data['id']);
            $this->db->bind(':name', $data['name']);
            $this->db->bind(':email', $data['email']);
            $this->db->bind(':password', $data['password']);
            $this->db->bind(':country', $data['country']);
            $this->db->bind(':role', $data['role']);

            if($this->db->execute()){
                return true;
            } else {
                return false;
            }
        }

        public function deleteUser($id){
            $this->db->query('DELETE * FROM users WHERE id = :id');
            $this->db->bind(':id', $id);

            return $this->db->execute();

            // if($this->db->execute()){
            //     return true;
            // } else {
            //     return false;
            // }
        }


    }