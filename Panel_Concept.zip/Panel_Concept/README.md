# Panel_Concept
Admin Panel Application (PHP MVC)

javascript library used for charts - amCharts.

Admin Dashboard Application done with PHP and MySQl as backend and HTML5, CSS3, Bootstrap and Javascript as Frontend.

All charts are fully functional and are connected to database.

LIVE DEMO: https://panel-concept.000webhostapp.com

Register new account or login with test account:

Username: testacc

Password: conceptdashboard321



